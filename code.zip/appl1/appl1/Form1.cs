﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace appl1
{
    public partial class Form1 : Form
    {
        double total1=0;
        double total2=0;
        public Form1()
        {
            InitializeComponent();
        }

        private void threebtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text =texDisplay.Text + threebtn.Text;
        }

        private void twobtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + twobtn.Text;
        }

        private void onebtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + onebtn.Text;
        }

        private void zerobtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + zerobtn.Text;
        }

        private void texDisplay_TextChanged(object sender, EventArgs e)
        {

        }

        private void fourbtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + fourbtn.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void fivebtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + fivebtn.Text;
        }

        private void sixbtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + sixbtn.Text;
        }

        private void sevenbtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + sevenbtn.Text;
        }

        private void eightbtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + eightbtn.Text;
        }

        private void ninebtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + ninebtn.Text;
        }

        private void pointbtn_Click(object sender, EventArgs e)
        {
            texDisplay.Text = texDisplay.Text + pointbtn.Text;
        }

        private void clrbtn_Click(object sender, EventArgs e)
        {
            texDisplay.Clear();
        }
         string theoperator;
        private void eqlbtn_Click(object sender, EventArgs e)
        {
            switch (theoperator)
            {
                case "+":
                    total2 = total1 + double.Parse(texDisplay.Text);
                    break;
                case "-":

                    total2 = total1 - double.Parse(texDisplay.Text);
                    break;
                case "*":
                    total2 = total1 * double.Parse(texDisplay.Text);
                    break;
                case "/":
                    total2 = total1 / double.Parse(texDisplay.Text);
                    break;
            }
                texDisplay.Text=total2.ToString();
            total1=0;
        }
       
        private void addbtn_Click(object sender, EventArgs e)
        {
            total1=total1+double.Parse(texDisplay.Text);
            texDisplay.Clear();
            theoperator = "+";
            
        }
        
        private void minusbtn_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(texDisplay.Text);
            texDisplay.Clear();
            theoperator = "-";
        }

        private void btnmultiply_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(texDisplay.Text);
            texDisplay.Clear();
            theoperator = "*";
        }

        private void dividebtn_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(texDisplay.Text);
            texDisplay.Clear();
            theoperator = "/";
        }
    }
}
