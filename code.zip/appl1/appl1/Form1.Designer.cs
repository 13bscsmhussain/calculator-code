﻿namespace appl1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.texDisplay = new System.Windows.Forms.TextBox();
            this.zerobtn = new System.Windows.Forms.Button();
            this.onebtn = new System.Windows.Forms.Button();
            this.twobtn = new System.Windows.Forms.Button();
            this.threebtn = new System.Windows.Forms.Button();
            this.fourbtn = new System.Windows.Forms.Button();
            this.fivebtn = new System.Windows.Forms.Button();
            this.sixbtn = new System.Windows.Forms.Button();
            this.sevenbtn = new System.Windows.Forms.Button();
            this.eightbtn = new System.Windows.Forms.Button();
            this.ninebtn = new System.Windows.Forms.Button();
            this.addbtn = new System.Windows.Forms.Button();
            this.eqlbtn = new System.Windows.Forms.Button();
            this.clrbtn = new System.Windows.Forms.Button();
            this.pointbtn = new System.Windows.Forms.Button();
            this.minusbtn = new System.Windows.Forms.Button();
            this.dividebtn = new System.Windows.Forms.Button();
            this.btnmultiply = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // texDisplay
            // 
            this.texDisplay.Location = new System.Drawing.Point(66, 51);
            this.texDisplay.Name = "texDisplay";
            this.texDisplay.Size = new System.Drawing.Size(200, 20);
            this.texDisplay.TabIndex = 0;
            this.texDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.texDisplay.TextChanged += new System.EventHandler(this.texDisplay_TextChanged);
            // 
            // zerobtn
            // 
            this.zerobtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zerobtn.Location = new System.Drawing.Point(133, 396);
            this.zerobtn.Name = "zerobtn";
            this.zerobtn.Size = new System.Drawing.Size(49, 40);
            this.zerobtn.TabIndex = 1;
            this.zerobtn.Text = "0";
            this.zerobtn.UseVisualStyleBackColor = true;
            this.zerobtn.Click += new System.EventHandler(this.zerobtn_Click);
            // 
            // onebtn
            // 
            this.onebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.onebtn.Location = new System.Drawing.Point(21, 155);
            this.onebtn.Name = "onebtn";
            this.onebtn.Size = new System.Drawing.Size(49, 40);
            this.onebtn.TabIndex = 2;
            this.onebtn.Text = "1";
            this.onebtn.UseVisualStyleBackColor = true;
            this.onebtn.Click += new System.EventHandler(this.onebtn_Click);
            // 
            // twobtn
            // 
            this.twobtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twobtn.Location = new System.Drawing.Point(133, 155);
            this.twobtn.Name = "twobtn";
            this.twobtn.Size = new System.Drawing.Size(49, 40);
            this.twobtn.TabIndex = 3;
            this.twobtn.Text = "2";
            this.twobtn.UseVisualStyleBackColor = true;
            this.twobtn.Click += new System.EventHandler(this.twobtn_Click);
            // 
            // threebtn
            // 
            this.threebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threebtn.Location = new System.Drawing.Point(247, 155);
            this.threebtn.Name = "threebtn";
            this.threebtn.Size = new System.Drawing.Size(49, 40);
            this.threebtn.TabIndex = 4;
            this.threebtn.Text = "3";
            this.threebtn.UseVisualStyleBackColor = true;
            this.threebtn.Click += new System.EventHandler(this.threebtn_Click);
            // 
            // fourbtn
            // 
            this.fourbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourbtn.Location = new System.Drawing.Point(21, 245);
            this.fourbtn.Name = "fourbtn";
            this.fourbtn.Size = new System.Drawing.Size(49, 40);
            this.fourbtn.TabIndex = 5;
            this.fourbtn.Text = "4";
            this.fourbtn.UseVisualStyleBackColor = true;
            this.fourbtn.Click += new System.EventHandler(this.fourbtn_Click);
            // 
            // fivebtn
            // 
            this.fivebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fivebtn.Location = new System.Drawing.Point(133, 245);
            this.fivebtn.Name = "fivebtn";
            this.fivebtn.Size = new System.Drawing.Size(49, 40);
            this.fivebtn.TabIndex = 6;
            this.fivebtn.Text = "5";
            this.fivebtn.UseVisualStyleBackColor = true;
            this.fivebtn.Click += new System.EventHandler(this.fivebtn_Click);
            // 
            // sixbtn
            // 
            this.sixbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sixbtn.Location = new System.Drawing.Point(247, 245);
            this.sixbtn.Name = "sixbtn";
            this.sixbtn.Size = new System.Drawing.Size(49, 40);
            this.sixbtn.TabIndex = 7;
            this.sixbtn.Text = "6";
            this.sixbtn.UseVisualStyleBackColor = true;
            this.sixbtn.Click += new System.EventHandler(this.sixbtn_Click);
            // 
            // sevenbtn
            // 
            this.sevenbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sevenbtn.Location = new System.Drawing.Point(21, 322);
            this.sevenbtn.Name = "sevenbtn";
            this.sevenbtn.Size = new System.Drawing.Size(49, 40);
            this.sevenbtn.TabIndex = 8;
            this.sevenbtn.Text = "7";
            this.sevenbtn.UseVisualStyleBackColor = true;
            this.sevenbtn.Click += new System.EventHandler(this.sevenbtn_Click);
            // 
            // eightbtn
            // 
            this.eightbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eightbtn.Location = new System.Drawing.Point(133, 322);
            this.eightbtn.Name = "eightbtn";
            this.eightbtn.Size = new System.Drawing.Size(49, 40);
            this.eightbtn.TabIndex = 9;
            this.eightbtn.Text = "8";
            this.eightbtn.UseVisualStyleBackColor = true;
            this.eightbtn.Click += new System.EventHandler(this.eightbtn_Click);
            // 
            // ninebtn
            // 
            this.ninebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ninebtn.Location = new System.Drawing.Point(247, 322);
            this.ninebtn.Name = "ninebtn";
            this.ninebtn.Size = new System.Drawing.Size(49, 40);
            this.ninebtn.TabIndex = 10;
            this.ninebtn.Text = "9";
            this.ninebtn.UseVisualStyleBackColor = true;
            this.ninebtn.Click += new System.EventHandler(this.ninebtn_Click);
            // 
            // addbtn
            // 
            this.addbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbtn.Location = new System.Drawing.Point(347, 155);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(49, 40);
            this.addbtn.TabIndex = 11;
            this.addbtn.Text = "+";
            this.addbtn.UseVisualStyleBackColor = true;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // eqlbtn
            // 
            this.eqlbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eqlbtn.Location = new System.Drawing.Point(347, 245);
            this.eqlbtn.Name = "eqlbtn";
            this.eqlbtn.Size = new System.Drawing.Size(49, 40);
            this.eqlbtn.TabIndex = 12;
            this.eqlbtn.Text = "=";
            this.eqlbtn.UseVisualStyleBackColor = true;
            this.eqlbtn.Click += new System.EventHandler(this.eqlbtn_Click);
            // 
            // clrbtn
            // 
            this.clrbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clrbtn.Location = new System.Drawing.Point(347, 322);
            this.clrbtn.Name = "clrbtn";
            this.clrbtn.Size = new System.Drawing.Size(49, 40);
            this.clrbtn.TabIndex = 13;
            this.clrbtn.Text = "Clear";
            this.clrbtn.UseVisualStyleBackColor = true;
            this.clrbtn.Click += new System.EventHandler(this.clrbtn_Click);
            // 
            // pointbtn
            // 
            this.pointbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pointbtn.Location = new System.Drawing.Point(247, 396);
            this.pointbtn.Name = "pointbtn";
            this.pointbtn.Size = new System.Drawing.Size(49, 40);
            this.pointbtn.TabIndex = 14;
            this.pointbtn.Text = ".";
            this.pointbtn.UseVisualStyleBackColor = true;
            this.pointbtn.Click += new System.EventHandler(this.pointbtn_Click);
            // 
            // minusbtn
            // 
            this.minusbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minusbtn.Location = new System.Drawing.Point(347, 77);
            this.minusbtn.Name = "minusbtn";
            this.minusbtn.Size = new System.Drawing.Size(49, 40);
            this.minusbtn.TabIndex = 15;
            this.minusbtn.Text = "-";
            this.minusbtn.UseVisualStyleBackColor = true;
            this.minusbtn.Click += new System.EventHandler(this.minusbtn_Click);
            // 
            // dividebtn
            // 
            this.dividebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dividebtn.Location = new System.Drawing.Point(347, 396);
            this.dividebtn.Name = "dividebtn";
            this.dividebtn.Size = new System.Drawing.Size(49, 40);
            this.dividebtn.TabIndex = 16;
            this.dividebtn.Text = "/";
            this.dividebtn.UseVisualStyleBackColor = true;
            this.dividebtn.Click += new System.EventHandler(this.dividebtn_Click);
            // 
            // btnmultiply
            // 
            this.btnmultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmultiply.Location = new System.Drawing.Point(347, 12);
            this.btnmultiply.Name = "btnmultiply";
            this.btnmultiply.Size = new System.Drawing.Size(49, 40);
            this.btnmultiply.TabIndex = 17;
            this.btnmultiply.Text = "*";
            this.btnmultiply.UseVisualStyleBackColor = true;
            this.btnmultiply.Click += new System.EventHandler(this.btnmultiply_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.ClientSize = new System.Drawing.Size(424, 448);
            this.Controls.Add(this.btnmultiply);
            this.Controls.Add(this.dividebtn);
            this.Controls.Add(this.minusbtn);
            this.Controls.Add(this.pointbtn);
            this.Controls.Add(this.clrbtn);
            this.Controls.Add(this.eqlbtn);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.ninebtn);
            this.Controls.Add(this.eightbtn);
            this.Controls.Add(this.sevenbtn);
            this.Controls.Add(this.sixbtn);
            this.Controls.Add(this.fivebtn);
            this.Controls.Add(this.fourbtn);
            this.Controls.Add(this.threebtn);
            this.Controls.Add(this.twobtn);
            this.Controls.Add(this.onebtn);
            this.Controls.Add(this.zerobtn);
            this.Controls.Add(this.texDisplay);
            this.ForeColor = System.Drawing.Color.Silver;
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox texDisplay;
        private System.Windows.Forms.Button zerobtn;
        private System.Windows.Forms.Button onebtn;
        private System.Windows.Forms.Button twobtn;
        private System.Windows.Forms.Button threebtn;
        private System.Windows.Forms.Button fourbtn;
        private System.Windows.Forms.Button fivebtn;
        private System.Windows.Forms.Button sixbtn;
        private System.Windows.Forms.Button sevenbtn;
        private System.Windows.Forms.Button eightbtn;
        private System.Windows.Forms.Button ninebtn;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.Button eqlbtn;
        private System.Windows.Forms.Button clrbtn;
        private System.Windows.Forms.Button pointbtn;
        private System.Windows.Forms.Button minusbtn;
        private System.Windows.Forms.Button dividebtn;
        private System.Windows.Forms.Button btnmultiply;
    }
}

